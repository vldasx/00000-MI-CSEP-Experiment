# CSEP — Conceptual Space Expansion Prompting

## Process documentation & reproducibility package

This package contains the complete experimental record of the CSEP investigation: documentation, tools, and data produced during a single extended working session.

---

## What's inside

```
csep_package/
├── README.md                              ← this file
├── documentation/
│   └── CSEP_Process_Documentation.pdf     ← full process documentation (15 sections)
├── tools/
│   ├── csep_v2_test.jsx                   ← the winning pipeline (4/4)
│   ├── csep_vs_baseline.jsx               ← CSEP v1 (1/4)
│   ├── advanced_cot_test.jsx              ← Advanced CoT control (2/4)
│   ├── cot_test.jsx                       ← Standard CoT control (not executed)
│   ├── haiku_hard_test.jsx                ← Baseline on 20 altered classics
│   ├── haiku_curated_test.jsx             ← 30 hand-curated questions test
│   ├── question_filter_v2.jsx             ← Two-step question generator
│   ├── question_filter.jsx                ← One-step question generator (deprecated)
│   ├── csep_batch_evaluated.jsx           ← Early 10-question batch test with judging
│   ├── csep_batch_test.jsx                ← Early 10-question batch test without judging
│   ├── csep_pipeline_test.jsx             ← First CSEP v1 single-question test
│   └── haiku_baseline_100.jsx             ← Early 100-question baseline
└── data/
    ├── hard_questions.json                ← 20 altered classics (core dataset)
    ├── haiku_hard_failures.json           ← 4 Haiku baseline failures
    ├── csep_vs_baseline_4.json            ← CSEP v1 results (1/4)
    ├── csep_v2_results.json               ← CSEP v2 results (4/4)
    ├── advanced_cot_results.json          ← Advanced CoT results (2/4)
    ├── curated_questions.json             ← 30 hand-curated questions
    ├── questions.json                     ← Earlier 100-question generated set
    ├── all_questions_60.json              ← Mode-collapsed 60-question run
    ├── csep_test_questions.json           ← 5 failures from generator iteration 2
    └── csep_test_questions2_.json         ← 3 failures from generator iteration 3
```

---

## How to read this package

**Start with the PDF.** `documentation/CSEP_Process_Documentation.pdf` is the full narrative: motivation from the bachelor thesis, dataset iterations, CSEP v1 design, negative result analysis, CSEP v2 redesign, CoT control, final interpretation, and reproducibility guide. It cites which tool and which data file corresponds to each step.

**Then inspect the tools.** Every tool is a single JSX file that runs as a Claude Artifact. They are self-contained — each has its questions embedded, its own localStorage key, and its own download buttons.

**Then inspect the data.** All data files are JSON. The three most important are:

- `hard_questions.json` — the 20-question test set
- `csep_v2_results.json` — full per-phase output showing how CSEP v2 succeeds
- `advanced_cot_results.json` — full reasoning traces showing advanced CoT diagnoses traps but cannot escape them

---

## Core finding in one sentence

**Recitation-over-reasoning is not a failure of reasoning effort; it is a failure of processing order, and can be fixed by requiring the model to parse the prompt (extract concepts, analyze what is asked, check for pattern-match risk) before any attempt to generate an answer.**

Empirical demonstration on 4 altered-classic puzzles where baseline Haiku 4.5 fails:

| Method | Result |
|--------|--------|
| Baseline | 0/4 (0%) |
| Advanced CoT (Tree of Thoughts + adversarial self-check) | 2/4 (50%) |
| CSEP v1 (hypothesis-first pipeline) | 1/4 (25%) |
| **CSEP v2 (prompt-first pipeline)** | **4/4 (100%)** |

---

## Quick reproduction

1. Load any JSX tool from `tools/` into a Claude Artifacts session.
2. The tool has its questions embedded; click "Run" to execute.
3. Results save to browser localStorage automatically.
4. Click "Download" to export results as JSON.
5. Compare against the corresponding file in `data/` for reference.

The models used were `claude-haiku-4-5-20251001` (target) and `claude-opus-4-5-20250929` (judge). API access is handled by the Artifacts environment.

---

## Key literature referenced

- **RoR-Bench** (Yan et al., 2025) — documents "recitation over reasoning" failure mode
- **Easy Problems That LLMs Get Wrong** (Williams & Huckle, 2024) — altered classical puzzles
- **Altered Riddles Dataset** (marcodsn, 2025, HuggingFace) — gender-bias riddle variations
- **BrainBench** (Tang, 2025) — commonsense reasoning benchmarks including rental-car-return case
- **Tree of Thoughts** (Yao et al., 2023) — basis for advanced CoT control
- **Self-Consistency** (Wang et al., 2022) — basis for convergence check
- **Bachelor thesis** (Miletin, 2025, IU) — original Micro Interventions framework

---

## What's not in this package

- Full runs of standard CoT (was built but not executed).
- Scaled runs on all 20 altered classics (4-question subset only).
- Ablation studies isolating the three new features in CSEP v2.
- Cross-model generalization (only Haiku 4.5 tested).

These are the obvious next experiments. The package is structured to make them easy to build on top of.
